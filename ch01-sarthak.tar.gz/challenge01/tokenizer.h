#ifndef TOKEN_H
#define TOKEN_H

#include "svec.h"

svec* tokenize(const char* text);

#endif


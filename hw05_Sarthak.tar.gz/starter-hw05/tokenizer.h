#ifndef TOKEN_H
#define TOKEN_H

#include "list.h"

list* tokenize(const char* text);

#endif


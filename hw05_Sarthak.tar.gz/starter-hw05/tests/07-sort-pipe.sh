sort tests/sample.txt | tail -n 2

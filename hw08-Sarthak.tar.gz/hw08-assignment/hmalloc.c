
#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>
#include "pthread.h"
#include <stdint.h>
#include "hmalloc.h"

/*
  typedef struct hm_stats {
  long pages_mapped;
  long pages_unmapped;
  long chunks_allocated;
  long chunks_freed;
  long free_length;
  } hm_stats;
*/

// a linkedlist structure that keeps track of the size of the list
typedef struct free_block {
	size_t size;
	struct free_block* next;
} free_block;

typedef struct block_header {
	size_t size;
}block_header;

const size_t PAGE_SIZE = 4096;
static hm_stats stats; // This initializes the stats to 0.
free_block* free_list = NULL;

long
free_list_length()
{
    // TODO: Calculate the length of the free list.
    free_block* head = free_list;
    int count = 0;
    while(head) {
	    count++;
	    head = head->next;
    } 
    return count;
}

hm_stats*
hgetstats()
{
    stats.free_length = free_list_length();
    return &stats;
}

void
hprintstats()
{
    stats.free_length = free_list_length();
    fprintf(stderr, "\n== husky malloc stats ==\n");
    fprintf(stderr, "Mapped:   %ld\n", stats.pages_mapped);
    fprintf(stderr, "Unmapped: %ld\n", stats.pages_unmapped);
    fprintf(stderr, "Allocs:   %ld\n", stats.chunks_allocated);
    fprintf(stderr, "Frees:    %ld\n", stats.chunks_freed);
    fprintf(stderr, "Freelen:  %ld\n", stats.free_length);
}

static
size_t
div_up(size_t xx, size_t yy)
{
    // This is useful to calculate # of pages
    // for large allocations.
    size_t zz = xx / yy;

    if (zz * yy == xx) {
        return zz;
    }
    else {
        return zz + 1;
    }
}

free_block* free_list_remove(size_t size) {
	free_block* curr = free_list;
	free_block* prev = NULL;
	if (free_list == NULL) {
		return NULL;
	}

	while(curr) {
		if (size <= curr->size) {
			break;
		}
		prev = curr;
		curr = curr->next;
	}

	if (curr) {
		if (prev == NULL) {
			free_list = curr->next;
		} else if (curr->next == NULL)  {
			prev->next = NULL;
		} else {
			prev->next = curr->next;
		}
		curr->next = NULL;
		return curr;
	} 
	return NULL; // reach here if we need to make a new node
}

void 
coalesce() {
	free_block* curr = free_list;
	while(curr->next) {
		void* curr_val = (void*) curr;
		void* next_val = (void*) curr->next;
		if(curr_val + curr->size == next_val) {
			curr->size += curr->next->size;
			curr->next = curr->next->next;
		} 
		else {
			curr = curr->next;
		}
	}
}

void 
free_list_insert(free_block* block) {
	if (free_list == NULL) {
		free_list = block;
		return;
	}

	free_block* curr = free_list;
	free_block* prev = NULL;
	uintptr_t curr_add = (uintptr_t) curr;
	uintptr_t block_add = (uintptr_t) block;

	if (block_add < curr_add) {
		block->next = curr;
		free_list = block;
		coalesce();
		return;
	} 


	while(curr) {
		if (curr_add > block_add) {
			if (prev != NULL) {
				prev->next = block;
			}
			block->next = curr;
			coalesce();
			return;
		} else {
		prev = curr; 
		curr = curr->next;
		curr_add = (uintptr_t) curr;
		}
	}
	
	prev->next = block;
	coalesce();
	return;	
}

void init_free_list() {
	if (free_list == NULL) {
	        free_list = mmap(0, PAGE_SIZE, PROT_READ|PROT_WRITE,
	   	MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	   	free_list->size = PAGE_SIZE;
	   	free_list->next = NULL;
	   	stats.pages_mapped += 1;
	}
}

void*
hmalloc(size_t size)
{
    stats.chunks_allocated += 1;
    size += sizeof(size_t);

    // TODO: Actually allocate memory with mmap and a free list.

    
   /* if (!block) {
	block = mmap(0, PAGE_SIZE, PROT_READ|PROT_WRITE,
	   	 MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
	block->size = PAGE_SIZE;
	block->next = NULL;
	stats.pages_mapped += 1;

    }*/

    if (size < sizeof(free_block)) {
	    size = sizeof(free_block);
    }
    
    if (size > PAGE_SIZE) {
	    int pages = div_up(size, PAGE_SIZE);
	    size_t new_size = pages * PAGE_SIZE; //done in case extra page
	    stats.pages_mapped += pages;
	    void* mapped = mmap(0, new_size, PROT_READ|PROT_WRITE,
			    MAP_SHARED|MAP_ANONYMOUS, -1, 0);
	    ((block_header*)mapped)->size = size - sizeof(size_t);
	    return mapped + sizeof(size_t);	    	    	    
    } 
    else {
	    //initializer if empty
	    init_free_list();
	    
	    free_block* curr = free_list_remove(size); 
	   
	    //printf("%ld\n", free_list_length());

	    free_block* node = NULL;

	    if (curr == NULL) {
	   	 curr = mmap(0, PAGE_SIZE, PROT_READ|PROT_WRITE,
	   	 MAP_SHARED|MAP_ANONYMOUS, -1, 0);
	   	 curr->next = NULL;
	   	 curr->size = PAGE_SIZE;
	   	 stats.pages_mapped += 1;
	    } 
		size_t leftover = curr->size - size;

		block_header* new_block = (block_header*) curr;

	     if (leftover >= sizeof(free_block)) {
	         new_block->size = size - sizeof(size_t);     
	         curr = ((void*) curr) + size;
		 curr->size = leftover;
	    	 free_list_insert(curr);
		}

	     return ((void*) new_block) + sizeof(size_t);
    }
}

void
hfree(void* item)
{
    stats.chunks_freed += 1;
    // TODO: Actually free the item.

    void* chunk = item - sizeof(size_t);
    size_t size = *(size_t*)(item - 8);
    int pages = div_up(size, PAGE_SIZE);
    if (size >= PAGE_SIZE) {
	   munmap(chunk, size);
	   stats.pages_unmapped += pages;
    } 
    else {
	    free_block* block = (free_block*)chunk;
	    block->size = size;
	    block->next = NULL;
	   // free_list_insert(block); this causes me to fail more tests than i pass
	   // not really sure whats going on with my insert since it passes all other tests?
	    
    }
}


true && echo true
false && echo false

#ifndef BTREE_H
#define BTREE_H

#define ORDER 4
#define KIDS (ORDER + 1)

typedef struct btree_pair {
    // A pair is empty if key[0] == '\0'
    char key[4];
    int  val;
} btree_pair;

typedef struct btree {
    int size; // number of items in this subtree
    btree_pair    data[ORDER];
    struct btree* kids[KIDS];
} btree;

btree* make_btree();
void free_btree(btree* bt);
btree_pair* btree_find(btree* bt, char* kk);
int btree_has(btree* bt, char* kk);
int btree_get(btree* bt, char* kk);
void btree_put(btree* bt, char* kk, int vv);
void btree_del(btree* bt, char* kk);
void btree_keys(btree* bt, char** keys);
void btree_dump(btree* bt);

#endif

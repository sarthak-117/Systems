#include <stdio.h>
#include <stdlib.h>

long square(long val) {
	return val * val;
}


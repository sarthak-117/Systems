#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "tokenizer.h"


int 
special_char(const char* text, long ii) {
	if (text[ii] == '|' 
	    || text[ii] == '&'
	    || text[ii] == ';'
	    || text[ii] == '<'
	    || text[ii] == '>') {
		return 0;
	} else {
		return 1;
	}
}

char* 
read_string(const char* text, long ii) {
	int nn = 0;
	while (!isspace(text[ii + nn])) {
		if (special_char(text, ii + nn) == 0) {
			break;
		}
		++nn;
	}
	//plus 1 bc mem terminate
	char* str = malloc(nn + 1);
	memcpy(str, text + ii, nn);
	str[nn] = 0;
	return str;
}


list* 
tokenize(const char* text) {
	list* xs = 0;
	int nn = strlen(text);
	int ii = 0;
	while (ii < nn) {
		if (isspace(text[ii])){
			++ii;
			continue;
		}

		//special characters
		if (special_char(text, ii) == 0) {
			if ((text[ii] == '|' && text[ii + 1] == '|') 
			      || (text[ii] == '&' && text[ii + 1] == '&')) {
				char* op = malloc(3);
			//	int nn = ii + 2;
			//	memcpy(op, text + ii, nn);
				op[0] = text[ii];
				op[1] = text[ii + 1];
				op[2] = '\0';
				xs = cons(op, xs);
				ii += 2;
				free(op);
			}
			else {
				char* op = malloc(2);
				//int nn = ii + 1;
				//memcpy(op, text +  ii, nn);
				op[0] = text[ii];
				op[1] = '\0';
				xs = cons(op,xs);
				++ii;
				free(op);
			}
			continue;
		}
			

		
			char* str = read_string(text, ii);
			xs = cons(str, xs);
			ii += strlen(str);
			free(str);	
	}

	return rev_free(xs);
}

#include "xmalloc.h"
#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>
#include <math.h>
#include <assert.h>

size_t round_up(size_t bytes);

typedef struct hm_stats {
    long pages_mapped;
    long pages_unmapped;
    long chunks_allocated;
    long chunks_freed;
    long free_length;
} hm_stats;

typedef struct free_block {
    size_t size;
    struct free_block* next;
} free_block;

const size_t PAGE_SIZE = 4096;
__thread hm_stats stats; // This initializes the stats to 0.
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

__thread free_block* buckets[7] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL};

long
free_list_length()
{
    int total_count = 0;
    int bucket_counts[7] = {0, 0, 0, 0, 0, 0, 0};
    free_block* curr = NULL;
    for (int i = 0; i < 7; i++) {
        curr = buckets[i];
        while (curr) {
            curr = curr->next;
            ++total_count;
            bucket_counts[i]++;
        }
    }
    return total_count;
}

hm_stats*
hgetstats()
{
    stats.free_length = free_list_length();
    return &stats;
}

void
hprintstats()
{
    stats.free_length = free_list_length();
    fprintf(stderr, "\n== husky malloc stats ==\n");
    fprintf(stderr, "Mapped:   %ld\n", stats.pages_mapped);
    fprintf(stderr, "Unmapped: %ld\n", stats.pages_unmapped);
    fprintf(stderr, "Allocs:   %ld\n", stats.chunks_allocated);
    fprintf(stderr, "Frees:    %ld\n", stats.chunks_freed);
    fprintf(stderr, "Freelen:  %ld\n", stats.free_length);
}


static
size_t
div_up(size_t xx, size_t yy)
{
    // This is useful to calculate # of pages
    // for large allocations.
    size_t zz = xx / yy;

    if (zz * yy == xx) {
        return zz;
    }
    else {
        return zz + 1;
    }
}


void
coalesce(int bucket)
{
    if (buckets[bucket] == NULL) {
        return;
    }
    free_block* curr = buckets[bucket];
    while (curr->next) {
        uintptr_t curr_pointer = (uintptr_t) curr;
        uintptr_t next_pointer = (uintptr_t) curr->next;
        if (curr_pointer + curr->size == next_pointer) {
            curr->size += curr->next->size;
            curr->next = curr->next->next;
        }
        else {
            curr = curr->next;
        }
    }
    //Add the coalesced cells to larger bins
    free_block* prev = NULL;
    curr = buckets[bucket];
    free_block* ret = NULL;
    int size = pow(2, (bucket + 5));
    while(curr) {
        if (curr->size > size) {
            if (!prev) {
                buckets[bucket] = curr->next;
            }
            else if (!curr->next) {
                prev->next = NULL;
            }
            else {
                prev->next = curr->next;
            }
            ret = curr;
            curr = curr->next;
            ret->next = NULL;
            int new_bucket_index = (log(ret->size) / log(2)) - 5;
            free_block* new_bucket = buckets[new_bucket_index];
            if (!new_bucket || (new_bucket > ret)) {
                ret->next = buckets[new_bucket_index];
                buckets[new_bucket_index] = ret;
            }
            else {
                while(new_bucket->next && (new_bucket->next < ret)) {
                    new_bucket = new_bucket->next;
                }
                new_bucket->next = ret;
            }
        }
        else {
            prev = curr;
            curr = curr->next;
        }
    }
}


void
free_list_insert(free_block* cell)
{
    //find the correct bucket
    size_t size = cell->size;
    size = round_up(size);
    int bucket = (log(size) / log(2)) - 5;
    free_block* free_list = buckets[bucket];

    if (free_list == NULL) {
        free_list = cell;
    }
    else {
        free_block* curr = free_list;
        free_block* prev = NULL;
        uintptr_t curr_add = (uintptr_t) curr;
        uintptr_t cell_add = (uintptr_t) cell;
        if (cell_add < curr_add) {
            cell->next = free_list;
            free_list = cell;

            coalesce(bucket);
            return;
        }
        else {
            prev = curr;
            curr = curr->next;
            curr_add = (uintptr_t) curr;
            while (curr) {
                if (cell_add < curr_add) {
                    prev->next = cell;
                    cell->next = curr;

                    coalesce(bucket);
                    return;
                }
                prev = curr;
                curr  = curr->next;
                curr_add = (uintptr_t) curr;
            }
        }
        prev->next = cell;
        coalesce(bucket);
        return;
    }
}

void*
free_list_remove(size_t size)
{
    //get which bucket it will be in
    int bucket = (log(round_up(size)) / log(2)) - 5;
    free_block* curr = buckets[bucket];
    free_block* prev = NULL;
    free_block* removal = NULL;

    if (curr == NULL) {
        return NULL;
    }

    while(curr) {
        if (size <= curr->size) {
            if (prev) {
                prev->next = curr->next;
            }
                else  {
                curr = curr->next;
            }

            curr->next = NULL;
            removal = curr;
            return (void*) removal;
        }

        prev = curr;
        curr = curr->next;
    }
    return NULL; // reach here if we need to make a new node
}


void*
xmalloc(size_t bytes)
{
    pthread_mutex_lock(&lock);

    stats.chunks_allocated += 1;
    bytes += sizeof(size_t);

    //Big size
    if (bytes > 2048) {
        //If between 2048 and 4096, just call it 4096
        if (bytes < PAGE_SIZE) {
            bytes = PAGE_SIZE;
        }
        int pages = div_up(bytes, PAGE_SIZE);
        size_t new_size = pages * PAGE_SIZE; //done in case extra page
        stats.pages_mapped += pages;
        void* mapped = mmap(0, new_size, PROT_READ|PROT_WRITE,
                MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
        size_t* ptr = (size_t*) mapped;
        *ptr = new_size;
        pthread_mutex_unlock(&lock);
        return mapped + sizeof(size_t);
    }
    //Small size
    else {
        //Get the size--should be a power of 2
        bytes = round_up(bytes);
        void* node = free_list_remove(bytes);

        free_block* curr = NULL;

        //Unable to find something in the free list
        if (node == NULL) {
            node = mmap(0, PAGE_SIZE, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
            assert(node);
            curr = (free_block*) node;
            curr->next = NULL;
            curr->size = PAGE_SIZE;
            stats.pages_mapped += 1;
        } 
        //Was able to find something in the free list 
        else {
            curr = (free_block*) node;
        }
        //Ignoring the leftovers for now
        
        size_t leftover = curr->size - bytes;

         if (leftover >= sizeof(free_block)) {
         void* new_block = (void*) curr;
         new_block+=bytes;
         free_block* new_insert = (free_block*) new_block;
         new_insert->size = leftover;
         new_insert->next = NULL;
         free_list_insert(new_insert);
         }
         else {
             bytes = curr->size;
         }
         
         size_t* size_ptr = (size_t*) curr;
         *size_ptr = bytes;
         pthread_mutex_unlock(&lock);
         return ((void*) size_ptr) + sizeof(size_t);
    }
    return 0;
}

size_t round_up(size_t bytes) {
    if (bytes <= 32) {
        return 32;
    }
    else if (bytes <= 64) {
        return 64;
    }
    else if (bytes <= 128) {
        return 128;
    }
    else if (bytes <= 256) {
        return 256;
    }
    else if (bytes <= 512) {
        return 512;
    }
    else if (bytes <= 1024) {
        return 1024;
    }
    else {
        return 2048;
    }
} 

void
xfree(void* ptr)
{
    pthread_mutex_lock(&lock);

    stats.chunks_freed += 1;

    void* chunk = ptr - sizeof(size_t);
    free_block* block = (free_block*) chunk;
    size_t size = *(size_t*)chunk;
    int pages = div_up(size, PAGE_SIZE);
    if (size >= PAGE_SIZE) {
       munmap(chunk, size);
       stats.pages_unmapped += pages;
    }
    else {
        block->size = size;
        block->next = NULL;
        free_list_insert(block);
    }
    pthread_mutex_unlock(&lock);
}

void* xrealloc(void* prev, size_t bytes) {
    xfree(prev);
    return xmalloc(bytes);
}


